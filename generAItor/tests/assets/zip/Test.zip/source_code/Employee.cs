﻿
using System.ComponentModel.DataAnnotations.Schema;

namespace Backend.Models
{
    public class Employee
    {
        public int? id { get; set; }

        public string firstName { get; set; } = null!;

        public string lastName { get; set; } = null!;

        public DateTime dateOfBirth { get; set; }

        public string email { get; set; } = null!;

        public string phoneNumber { get; set; }

        public string address { get; set; } = null!;

        public string city { get; set; } = null!;

        public string state { get; set; } = null!;

        public string country { get; set; } = null!;

        public int? postalCode { get; set; }

        public int? PositionId { get; set; }
        public Position Position { get; set; }

        public string department { get; set; } = null!;

        public DateTime hireDate { get; set; }

        public double? salary { get; set; }

        // Reference to the manager or supervisor
        public int? reportsToId { get; set; }
        public Employee reportsTo { get; set; }

        // Collection of employees that report to this employee

        [NotMapped]
        public List<int?> subordinatesId { get; set; } = new List<int?>();
        public List<Employee> subordinates { get; set; } = new List<Employee>();
    }
}