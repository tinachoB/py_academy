﻿using Backend.Models;
using Microsoft.EntityFrameworkCore;

namespace Backend.Context
{
    public class BackendDbContext : DbContext
    {

        public BackendDbContext(DbContextOptions<BackendDbContext> options)
        : base(options)
        {
        }

        public DbSet<Employee> Employee { get; set; }
        public DbSet<Position> Position { get; set; }
        public DbSet<Subordinate> Subordinate { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Employee>()
                .HasOne(e => e.Position)
                .WithMany().IsRequired(false)
                .HasForeignKey(e => e.PositionId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Employee>()
                .HasMany(e => e.subordinates)
                .WithOne(e => e.reportsTo).IsRequired(false)
                .OnDelete(DeleteBehavior.Cascade);

            base.OnModelCreating(modelBuilder);
        }
    }
}
